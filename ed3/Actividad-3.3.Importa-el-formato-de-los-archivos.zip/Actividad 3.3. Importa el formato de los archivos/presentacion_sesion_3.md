# Contenido de la presentación para Claude

**Archivo fuente:** Presentación sesión 3 v2.1(1).pdf  
**Total de slides:** 43  
**Uso sugerido:** Copiar este Markdown en Claude como contexto de la presentación. Cada slide conserva título, texto extraído, descripción visual y observaciones.

---

## Slide 1: Curso de IA generativa, modelos de lenguaje para productividad y uso seguro en la empresa

### Título
Curso de IA generativa, modelos de lenguaje para productividad y uso seguro en la empresa

### Contenido de texto
```text
PENDIENTE
Curso de IA generativa, modelos de
lenguaje para productividad y uso
seguro en la empresa
Presenta: Erick Varela-Guzmán.
Junio, 2026
```

### Imagen / tabla disponible
Portada con fondo negro, logotipo Key x Professionals en la esquina superior izquierda, gran texto central del curso, etiqueta amarilla "PENDIENTE", nombre del presentador y fecha. Elementos gráficos azules decorativos al lado derecho.

### Observaciones
Contiene marca o texto de contenido pendiente.

---

## Slide 2: Actividad 3.1. ¿Qué recuerdas de la sesión 2?

### Título
Actividad 3.1. ¿Qué recuerdas de la sesión 2?

### Contenido de texto
```text
Actividad 3.1. ¿Que recuerdas de la sesión 2?
Instrucciones.
• Discute con un compañero cercano
los principales conceptos discutidos
en la sesión 2.
• ¿Que les pareció relevante?
• ¿Usaron Claude u otra IA generativa
durante la semana?
• Al finalizar, se invitará a un par de
compañeros del grupo para compartir
brevemente lo que conversaron.
```

### Imagen / tabla disponible
Ilustración de tres personas conversando en una mesa con laptop y temporizador visual de 05:00 en la esquina superior derecha. No hay tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 3: Agenda PENDIENTE

### Título
Agenda PENDIENTE

### Contenido de texto
```text
Agenda PENDIENTE

1. Fundamentos e introducción
2. ¿Cómo funciona la inteligencia
artificial?
3. Introducción a Claude
4. Conversaciones y proyectos
5. Resumen de documentos
6. Generación de documentos
7. Análisis de casos reales
8. Introducción a los LLM
```

### Imagen / tabla disponible
Agenda en dos columnas con ocho bloques numerados sobre fondo blanco. El título incluye una etiqueta amarilla "PENDIENTE". No hay imagen principal adicional.

### Observaciones
Contiene marca o texto de contenido pendiente. -- Revisar si la etiqueta PENDIENTE debe eliminarse o reemplazarse por contenido final.

---

## Slide 4: Tema 4.2 - Técnicas para la construcción de Prompts

### Título
Tema 4.2 - Técnicas para la construcción de Prompts

### Contenido de texto
```text
Tema 4.2
Técnicas para la
construcción de Prompts
Objetivo.
Aprender a construir instrucciones claras, estructuradas y efectivas para
obtener resultados de alta calidad de un LLM.
```

### Imagen / tabla disponible
Diapositiva de sección con fondo negro, franja azul superior y figura geométrica azul de marca a la derecha. No hay tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 5: ¿Qué es un Prompt?

### Título
¿Qué es un Prompt?

### Contenido de texto
```text
¿Qué es un Prompt?
“Es una petición en
lenguaje natural que
se envía a un modelo
de lenguaje para
obtener una
respuesta”
Google
“Información, frases o preguntas que se
introducen en una herramienta de IA
generativa para que el modelo analice la
información y genere una respuesta basada
en los patrones aprendidos durante su
entrenamiento”
Harvard University
```

### Imagen / tabla disponible
Imagen de fondo oscuro con una mano humana y una mano robótica tocándose, asociada al concepto de interacción humano-IA. Incluye dos citas comparativas, no una tabla formal.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 6: La calidad de la respuesta depende de la calidad de la solicitud

### Título
La calidad de la respuesta depende de la calidad de la solicitud

### Contenido de texto
```text
La calidad del respuesta depende de la calidad del solicitud.
Ejemplos
Ejemplos
'Hazme un resumen.'
'Escribe algo sobre liderazgo.'
'Ayúdame con mi correo.'
'Resume este documento en 5 puntos clave, en lenguaje
ejecutivo, para presentar a la junta directiva en menos de 200
palabras.'
'Redacta un párrafo introductorio para un taller de liderazgo
dirigido a gerentes de operaciones con 10+ años de
experiencia. Tono: motivador pero práctico.'
'Revisa este correo y sugiere cómo hacerlo más directo y
profesional. Conserva el mensaje central pero elimina el
relleno innecesario.'
```

### Imagen / tabla disponible
Tabla de dos columnas tituladas "Ejemplos". La columna izquierda contiene solicitudes vagas y la derecha ejemplos de prompts más específicos y contextualizados.

### Observaciones
Contiene estructura tipo tabla/tarjetas; conviene revisar alineación si se migra a otro formato.

---

## Slide 7: Estructura sugerida de un Prompt efectivo

### Título
Estructura sugerida de un Prompt efectivo

### Contenido de texto
```text
Estructura sugerida de un Prompt efectivo
Componente
Descripción y ejemplo
Rol
Define quién debe ser el modelo en esta interacción. Ejemplo: 'Actúa
como un especialista en comunicación interna corporativa.'
Contexto
Proporciona la información de fondo necesaria para que la respuesta sea
relevante. Ejemplo: 'Estoy preparando una comunicación para empleados
sobre un cambio en el proceso de solicitudes de vacaciones.'
Objetivo
Indica qué quieres obtener de manera específica. Ejemplo: 'Necesito un
correo claro, en español, que explique el cambio y sus beneficios.'
Formato
Especifica cómo debe presentarse la respuesta. Ejemplo: 'Máximo 150
palabras. Sin tecnicismos. Con un asunto sugerido para el correo.'
```

### Imagen / tabla disponible
Tabla con dos columnas: "Componente" y "Descripción y ejemplo". Presenta los bloques Rol, Contexto, Objetivo y Formato.

### Observaciones
Contiene estructura tipo tabla/tarjetas; conviene revisar alineación si se migra a otro formato.

---

## Slide 8: Técnicas de Prompting: encadenamiento

### Título
Técnicas de Prompting: encadenamiento

### Contenido de texto
```text
Técnicas de Prompting: encadenamiento
"Antes de responder, analiza el
problema paso a paso. Primero
identifica los factores relevantes,
luego evalúa cada uno, y
finalmente proporciona tu
recomendación."
Le pedimos al modelo que razone paso a paso
antes de llegar a una conclusión. Esto reduce
errores en tareas que requieren lógica o
análisis. Útil en:
• Análisis de problemas complejos con
múltiples variables
• Decisiones que requieren considerar pros y
contras
• Revisión de documentos o argumentos.
Wei, J., Wang, X., Schuurmans, D., Bosma, M., Xia, F., Chi, E., ... & Zhou, D. (2022). Chain-
of-thought prompting elicits reasoning in large language models. Advances in neural
information processing systems, 35, 24824-24837.
```

### Imagen / tabla disponible
Ilustración de una persona señalando un globo de diálogo con un ejemplo de prompt paso a paso. Incluye una cita bibliográfica en la parte inferior.

### Observaciones
Incluye referencia o enlace externo; validar vigencia antes de compartir.

---

## Slide 9: Técnicas de Prompting: Role Prompting

### Título
Técnicas de Prompting: Role Prompting

### Contenido de texto
```text
Técnicas de Prompting: Role Prompting
El modelo ajusta su tono, vocabulario y perspectiva según el rol que se le
asigna.
"Responde como si fueras el gerente de
operaciones de una empresa de distribución."
"Eres un coach de comunicación. Tu tarea es
ayudarme a mejorar este correo."
"Actúa como un experto en análisis financiero
con experiencia en el sector agroalimentario."
•
https://www.promptlayer.com/glossary/role-prompting/
```

### Imagen / tabla disponible
Tres globos de diálogo con ejemplos de roles asignados al modelo, acompañados por una ilustración de una persona en traje señalando. Incluye enlace a PromptLayer.

### Observaciones
Incluye referencia o enlace externo; validar vigencia antes de compartir.

---

## Slide 10: Checklist de verificación mínimo

### Título
Checklist de verificación mínimo

### Contenido de texto
```text
Checklist de verificación mínimo
Divide tareas complejas en pasos secuenciales dentro del mismo prompt.
Paso 1: 'Identifica los 3 principales problemas del texto adjunto.'
Paso 2: 'Para cada problema, propón una solución concreta.'
Paso 3: 'Genera un plan de acción con responsables y fechas
sugeridas.'
• https://www.promptlayer.com/glossary/prompt-scaffolding/
```

### Imagen / tabla disponible
Globo de diálogo grande con un ejemplo de prompt por pasos y una ilustración de una persona señalando. Incluye enlace a PromptLayer.

### Observaciones
Incluye referencia o enlace externo; validar vigencia antes de compartir.

---

## Slide 11: Actividad 3.2. Construcción de un asistente de Prompts

### Título
Actividad 3.2. Construcción de un asistente de Prompts

### Contenido de texto
```text
Actividad 3.2. Construcción de un asistente de Prompts
Instrucciones.
1.
Crea un proyecto como “asistente de
Prompts”.
2.
Piensa en una tarea real de tu trabajo
(un correo, un resumen, un
comparativo).
3.
En el proyecto describe la tarea en
lenguaje cotidiano al Asistente de
prompts, sin preocuparte por la
estructura ni incluir datos sensibles.
4.
Refina una vez con una frase de ajuste
(“más conciso”, “tono más formal”, “en
formato de tabla”).
```

### Imagen / tabla disponible
Ilustración de tres personas conversando en una mesa con laptop; acompaña instrucciones para crear un asistente de prompts. No hay tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 12: Paso 1. Crear un Proyecto

### Título
Paso 1. Crear un Proyecto

### Contenido de texto
```text
Paso 1. Crear un Proyecto
• Crear un nuevo Proyecto en Claude con
el nombre: Asistente de Prompts.
• Agrega la siguiente descripción:
Describe una tarea de tu trabajo en
lenguaje cotidiano y recibe un prompt
bien construido, listo para copiar.
Protege automáticamente los datos
sensibles que menciones.

```

### Imagen / tabla disponible
Captura de pantalla de la interfaz de Claude para crear un proyecto, con campos de nombre y descripción; a la izquierda se muestran las instrucciones en un recuadro gris.

### Observaciones
-- Incluye captura de pantalla de interfaz; si se actualiza Claude, la imagen podría quedar desactualizada.

---

## Slide 13: Paso 2. Configurar las instrucciones del Proyecto

### Título
Paso 2. Configurar las instrucciones del Proyecto

### Contenido de texto
```text
Paso 2. Configurar las instrucciones del Proyecto
Copiar y pegar las
instrucciones
proporcionadas por el
instructor en las
instrucciones del
proyecto.

```

### Imagen / tabla disponible
Captura de pantalla de la interfaz de Claude para configurar instrucciones de proyecto, junto a un recuadro con la indicación de copiar y pegar instrucciones.

### Observaciones
-- Incluye captura de pantalla de interfaz; si se actualiza Claude, la imagen podría quedar desactualizada.

---

## Slide 14: Paso 3. Identificar una tarea real

### Título
Paso 3. Identificar una tarea real

### Contenido de texto
```text
Paso 3. Identificar una tarea real

Ejemplos de tareas sugeridas:
•
Analizar liquidaciones médicas.
•
Resumir solicitudes de preautorización.
•
Elaborar respuestas a observaciones
administrativas.
•
Detectar patrones en rechazos de trámites.
•
Preparar reportes de productividad
operativa.
•
Redactar comunicaciones para asegurados.
•
Resumir pólizas extensas.
•
Generar respuestas a consultas frecuentes.
•
Analizar tendencias de siniestros.
•
Crear reportes ejecutivos sobre reclamos.
•
Preparar resúmenes de casos complejos para
supervisores.
```

### Imagen / tabla disponible
Dos paneles tipo tabla o tarjetas:cada uno con ejemplos de tareas sugeridas.
---

## Slide 15: Paso 4. Crear un Prompt con el asistente

### Título
Paso 4. Crear un Prompt con el asistente

### Contenido de texto
```text
Paso 4. Crear un Prompt con el asistente

Ingresar la descripción en lenguaje cotidiano al Proyecto, por ejemplo:
Necesito comparar varias solicitudes de liquidación y generar un resumen de
diferencias importantes para mi supervisor.
Refinar el resultado. Solicitar una mejora utilizando instrucciones breves como:
•
Más conciso.
•
Más formal.
•
En formato de tabla.
•
Orientado a gerencia.
•
En formato de lista de verificación.
•
Con recomendaciones accionables.
Seleccionar la mejor versión.
```

### Imagen / tabla disponible
Bloque de texto con ejemplo de prompt escrito en estilo monoespaciado/itálico azul y lista de posibles refinamientos. No hay imagen principal.

### Observaciones
--

---

## Slide 16: Tema 5 - Automatización de tareas periódicas con Claude

### Título
Tema 5 - Automatización de tareas periódicas con Claude

### Contenido de texto
```text
Tema 5
Automatización de tareas
periódicas con Claude
Objetivo.
Usar la sección de instrucciones de un proyecto para generar una plantilla de
prompt que produzca un documento cada cierto periodo, donde el usuario
solo debe iniciar conversación adjuntando los nuevos datos.
```

### Imagen / tabla disponible
Diapositiva de sección con fondo negro, franja azul superior y figura geométrica azul de marca a la derecha. No hay tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 17: La idea central del patrón de diseño

### Título
La idea central del patrón de diseño

### Contenido de texto
```text
Lo permanente
vive en el
Proyecto
Lo variable vive
en la
conversación
La idea central del patrón de diseño
```

### Imagen / tabla disponible
Captura de una interfaz de proyecto de Claude con dos recuadros naranjas que enfatizan la división entre lo variable en la conversación y lo permanente en el proyecto.

### Observaciones
Incluye captura de pantalla de interfaz; si se actualiza Claude, la imagen podría quedar desactualizada.

---

## Slide 18: Memoria entre conversaciones

### Título
Memoria entre conversaciones

### Contenido de texto
```text
Cada conversación nueva
empieza en blanco.
Lo único que persiste mes a
mes:
• Instrucciones del proyecto
• Archivos del proyecto
Implicación: las decisiones
permanentes deben vivir en
las instrucciones, no en el
historial de conversaciones.
Memoria entre conversaciones
```

### Imagen / tabla disponible
Captura de una interfaz de proyecto de Claude a la izquierda y texto explicativo a la derecha sobre memoria entre conversaciones. Un recuadro naranja destaca conversaciones anteriores.

### Observaciones
Incluye captura de pantalla de interfaz; si se actualiza Claude, la imagen podría quedar desactualizada.

---

## Slide 19: Plantilla de un Prompt reutilizable

### Título
Plantilla de un Prompt reutilizable

### Contenido de texto
```text
Plantilla de un Prompt reutilizable
ROL
FIJO
CONTEXTO
VARIABLE
OBJETIVO
FIJO
FORMATO
FIJO
+
+
+
Las variables son los únicos campos que cambian cada vez.
En este caso: el archivo Excel del mes en curso.
```

### Imagen / tabla disponible
Diagrama de flujo horizontal: ROL FIJO + CONTEXTO VARIABLE + OBJETIVO FIJO + FORMATO FIJO. El contexto variable está resaltado en naranja.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 20: Etapas del caso

### Título
Etapas del caso

### Contenido de texto
```text
Etapas del caso
01
Análisis estructural de
los datos
Entender qué hay en los
datos antes de
automatizar.
02
Documento de
referencia
Tomar un reporte real
existente como plantilla
viva.
03
Instrucciones del
proyecto
Integrar todo lo anterior
con reglas, tono y
comportamiento.
```

### Imagen / tabla disponible
Tres tarjetas grandes numeradas 01, 02 y 03 que resumen las etapas del caso: análisis estructural, documento de referencia e instrucciones del proyecto.

### Observaciones
Contiene estructura tipo tabla/tarjetas; conviene revisar alineación si se migra a otro formato.

---

## Slide 21: Actividad 3.3. Automatización básica de tareas periódicas

### Título
Actividad 3.3. Automatización básica de tareas periódicas

### Contenido de texto
```text
Actividad 3.3. Automatización básica de tareas periódicas
Objetivo de la actividad
Aprender a automatizar un documento que
se repite cada cierto tiempo, separando lo
que siempre es igual de lo que cambia cada
vez.
• Lo permanente (reglas, formato) vive en
las instrucciones del Proyecto.
• Lo variable (los datos del mes) vive en la
conversación.
```

### Imagen / tabla disponible
Ilustración de tres personas conversando en una mesa con laptop; acompaña el objetivo de automatización básica. No hay tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 22: Paso 1. Selección del documento de referencia

### Título
Paso 1. Selección del documento de referencia

### Contenido de texto
```text
Paso 1. Selección del documento de referencia
Se espera utilizar un documento real
No diseñamos uno nuevo. Usamos el reporte que ya se hace cada mes a mano.
Refleja la realidad
Ayuda a Claude a contextualizar según el trabajo que realizamos
Extracción, no creación
El proyecto enseña a Claude el formato existente, no inventa uno.
Sin marcadores ni placeholders
Claude es muy bueno imitando estructuras.
```

### Imagen / tabla disponible
Lista de cuatro criterios en bloques horizontales grises con una ilustración de documentos/checklist a la derecha.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 23: Paso 2. Plantilla de análisis estructural

### Título
Paso 2. Plantilla de análisis estructural

### Contenido de texto
```text
Paso 2. Plantilla de análisis estructural
Prompt que se ejecuta una vez en conversación independiente. El resultado se
pega como contexto en las instrucciones del proyecto. Ayuda a Claude a conocer
la estructura de los datos.
Debe incluir:
• Nombre del archivo y número de filas
• Rango temporal cubierto
• Lista de campos con tipo y descripción
• Rango de fechas por campo de fecha
• Valores únicos de campos categóricos
```

### Imagen / tabla disponible
Slide textual con lista de elementos que debe incluir la plantilla de análisis estructural. No hay imagen ni tabla.

### Observaciones
Contiene marca o texto de contenido pendiente.

---

## Slide 24: Paso 2. Plantilla de análisis estructural - Prompt

### Título
Paso 2. Plantilla de análisis estructural - Prompt

### Contenido de texto
```text
Paso 2. Plantilla de análisis estructural
Analiza el contenido completo del archivo adjunto y genera un resumen
estructural en texto plano. El archivo representa un mes de operación; la
estructura se repetirá en archivos mensuales futuros con las mismas columnas
pero distintos registros. El resumen se usará como instrucción de contexto.
Incluye:
- Nombre del archivo, número de filas y rango temporal (mes,año).
- Lista de campos con tipo de dato y descripción en una línea.
- Rango de fechas de cada campo de fecha (primer y último registro).
- Valores únicos de los campos categóricos.
Usa lista con guiones. Máximo 400 palabras.
```

### Imagen / tabla disponible
Bloque grande de texto tipo prompt en monoespaciado dentro de un recuadro azul. Funciona como plantilla reutilizable para análisis estructural.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 25: Paso 3. Crear un Proyecto

### Título
Paso 3. Crear un Proyecto

### Contenido de texto
```text
Paso 3. Crear un Proyecto
• Crear un nuevo Proyecto en Claude con
el nombre: Reporte Ejecutivo Mensual -
Producción Comercial.
• Agrega la siguiente descripción: Genera
el reporte ejecutivo mensual a partir
de los datos de producción del mes.
Mantiene formato, tono y estructura
consistentes mes a mes para Dirección
General.

```

### Imagen / tabla disponible
Captura de pantalla de Claude para crear un proyecto de "Reporte Ejecutivo Mensual - Producción Comercial", con el texto del nombre y la descripción del proyecto.

### Observaciones
-- Incluye captura de pantalla de interfaz; si se actualiza Claude, la imagen podría quedar desactualizada.

---

## Slide 26: Paso 4. Instrucciones del proyecto

### Título
Paso 4. Instrucciones del proyecto

### Contenido de texto
```text
Paso 4. Instrucciones del proyecto
Se integran las etapas previas en una instrucción de sistema completa, siguiendo
los 8 bloques de la presentación:
Ejemplos
Ejemplos
Rol y misión
¿Cuál es el rol y objetivo que debe adoptar Claude?
Contexto del negocio
¿Qué reglas del negocio se esperan aplicar?
Comportamiento al iniciar
¿Qué hace Claude al recibir un recibo?
Estructura de datos
El resumen estructural de la Etapa 1 pegado aquí
Reglas del negocio
Fórmulas y umbrales (tasa de pago / brecha / revisión gerencial).
Formato del documento
Mismo orden de secciones que el reporte de referencia.
Tono y estilo
Por ejemplo: Ejecutivo, español, sin tecnicismos innecesarios.
Manejo de errores
¿Qué hace Claude si encuentra alguna inconsistencia?
```

### Imagen / tabla disponible
Tabla de dos columnas que presenta ocho bloques para las instrucciones del proyecto: rol, contexto, comportamiento, estructura, reglas, formato, tono y manejo de errores.

### Observaciones
Contiene estructura tipo tabla/tarjetas; conviene revisar alineación si se migra a otro formato.

---

## Slide 27: Paso 5. Generación de reportes

### Título
Paso 5. Generación de reportes

### Contenido de texto
```text
Paso 5. Generación de reportes
Utilizar el siguiente Prompt para generar el reporte mensual.
Adjunto el archivo de producción comercial de
[mes] de 2026. Genera el reporte ejecutivo
mensual siguiendo las instrucciones del
proyecto.
```

### Imagen / tabla disponible
Recuadro central con un prompt reusable; el marcador [mes] aparece resaltado en amarillo como variable.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 28: Recomendaciones antes de utilizar el resultado

### Título
Recomendaciones antes de utilizar el resultado

### Contenido de texto
```text
Recomendaciones antes de utilizar el resultado
Comportamientos obligatorios
¿Se ejecutan los pasos al inicio de cada conversación?
Reglas de negocio
¿Los cálculos respetan las reglas documentadas?
Estructura del documento
¿Se mantiene fiel al documento de referencia?
Tono y formato
¿La salida es consistente entre meses?
```

### Imagen / tabla disponible
Imagen de una nota que dice "EXPERT OPINION" a la izquierda y cuatro bloques de revisión a la derecha: comportamientos, reglas, estructura, tono y formato.

### Observaciones
Contiene estructura tipo tabla/tarjetas; conviene revisar alineación si se migra a otro formato.

---

## Slide 29: ¿Y si necesito más escala?

### Título
¿Y si necesito más escala?

### Contenido de texto
```text
¿Y si necesito más escala?
• ¿Y si tuviera 50 propiedades en lugar de 2?
• ¿Y si los datos fueran diarios en lugar de
mensuales?
• ¿Y si necesitara reportes para múltiples
departamentos?
Recomendación:
En cierto volumen y complejidad, el patrón cede
ante BI, Python o bases de datos. Pero el patrón
mental sigue aplicando: separar lo permanente de
lo variable, externalizar las reglas, automatizar lo
repetitivo.
```

### Imagen / tabla disponible
Logotipos de Power BI y Power Automate a la derecha, usados para indicar alternativas de mayor escala. Texto con preguntas de escalabilidad a la izquierda.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 30: Actividad final: Construye tu propio caso

### Título
Actividad final: Construye tu propio caso

### Contenido de texto
```text
Actividad final:
Construye tu propio caso
```

### Imagen / tabla disponible
Diapositiva de transición con fondo oscuro tipo circuito/tecnología y texto central: "Actividad final: Construye tu propio caso".

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 31: Indicaciones

### Título
Indicaciones

### Contenido de texto
```text
Indicaciones
• Trabajo en parejas
• 45 minutos de diseño + 30
minutos de presentación
• Cada uno con el documento
que trajo de tarea
• Tu compañero será tu consultor
y viceversa.
```

### Imagen / tabla disponible
Ilustración de personas trabajando con un robot/IA y laptops a la derecha; instrucciones de trabajo en parejas a la izquierda.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 32: Antes de iniciar, ¿Qué técnica usar?

### Título
Antes de iniciar, ¿Qué técnica usar?

### Contenido de texto
```text
Antes de iniciar, ¿Qué técnica usar?
• Si tu documento se genera cada periodo con datos nuevos, usa el patrón Proyecto +
Plantilla (sesión 3)
• Si tienes datos en Excel que necesitas analizar, usa Claude for Excel.
• Si es un documento puntual, no recurrente, usa una conversación con análisis estructural
• Si quieres explorar un dataset sin objetivo fijo aún, usa una conversación con datos
adjuntos
• Sugerencia: no se queden más de 5 minutos eligiendo. Comenzar con la que mejor encaje
y ajusta sobre la marcha.
```

### Imagen / tabla disponible
Slide textual con recomendaciones para seleccionar la técnica adecuada antes de iniciar. No hay imagen principal ni tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 33: Etapa 1. Conozcan sus casos

### Título
Etapa 1. Conozcan sus casos

### Contenido de texto
```text
Etapa 1. Conozcan sus casos
Cada uno explica en su equipo (5 minutos
cada uno):
• Qué documento es y para qué se usa
• Quién lo recibe y con qué frecuencia se
genera
• Qué partes son fijas y qué partes cambian
• Qué reglas o criterios solo tú conoces
Quien escucha hace preguntas para conocer
lo mejor posible el contexto, no propone
soluciones todavía.
```

### Imagen / tabla disponible
Ilustración de equipo reunido en mesa a la derecha y temporizador 05:00. La izquierda contiene preguntas guía para conocer el caso.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 34: Etapa 2. Discutir

### Título
Etapa 2. Discutir

### Contenido de texto
```text
Etapa 2. Discutir
Lo que deben producir:
• Qué técnica del curso aplicarán
• Qué partes son permanentes y qué partes
son variables
• Qué reglas del negocio deben quedar
documentadas
• Un primer borrador de instrucciones,
prompt o flujo
```

### Imagen / tabla disponible
Ilustración de equipo reunido en mesa a la derecha y temporizador 05:00. La izquierda lista los entregables de discusión.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 35: Etapa 3. ¡A trabajar!

### Título
Etapa 3. ¡A trabajar!

### Contenido de texto
```text
Etapa 3. ¡A trabajar!
Indicaciones pendientes
```

### Imagen / tabla disponible
Ilustración de equipo reunido en mesa a la derecha y temporizador 05:00. Contiene una etiqueta amarilla de indicaciones pendientes.

### Observaciones
Contiene marca o texto de contenido pendiente.

---

## Slide 36: Etapa 4. Preparen su presentación

### Título
Etapa 4. Preparen su presentación

### Contenido de texto
```text
Etapa 4. Preparen su presentación
Cada pareja presentará en 3 minutos
siguiendo este formato:
• 30 segundos: Qué documento es
• 30 segundos: Qué problema resuelve
la automatización
• 30 segundos: Qué técnica del curso
usaron
• 60 segundos: Una dificultad o duda
que tuvieron
```

### Imagen / tabla disponible
Ilustración de equipo reunido en mesa a la derecha y temporizador 05:00. La izquierda muestra el formato cronometrado para presentación de 3 minutos.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 37: Cierre sesión 3

### Título
Cierre sesión 3

### Contenido de texto
```text
Cierre sesión 3
Objetivo.
Consolidar los aprendizajes de la sesión a través de la reflexión colectiva,
identificando qué herramientas y técnicas aplicarán primero en su trabajo.
```

### Imagen / tabla disponible
Diapositiva de cierre con fondo negro, franja azul y figura geométrica azul de marca. No hay tabla.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 38: Ideas clave de esta sesión PENDIENTE

### Título
Ideas clave de esta sesión PENDIENTE

### Contenido de texto
```text
Ideas clave de esta sesión PENDIENTE
La IA amplifica tu criterio,no lo reemplaza. Ser usuario competente significa
saber cuándo confiar y cuándo verificar.
Un LLM no entiende, si no que predice. Esa distinción define sus
capacidades y sus límites.
Cada área tiene sus propios casos de uso: identifícalos, priorizalos con la
matriz Impacto vs. Esfuerzo y empieza por los Quick Wins.
Los artefactos y las integraciones (Excel, Chrome) convierten a Claude en
parte de tu flujo de trabajo, no solo de tu chat.
```

### Imagen / tabla disponible
Lista de ideas clave con iconos pequeños tipo foco. El título incluye una etiqueta amarilla "PENDIENTE".

### Observaciones
Contiene marca o texto de contenido pendiente. Revisar si la etiqueta PENDIENTE debe eliminarse o reemplazarse por contenido final.

---

## Slide 39: Lo que construiste en este curso PENDIENTE

### Título
Lo que construiste en este curso PENDIENTE

### Contenido de texto
```text
Lo que construiste en este curso PENDIENTE
Cuenta activa personal de Claude AI (ya la usaste en las actividades).
Primer Proyecto de Claude configurado en tu cuenta de Claude, con instrucciones
de sistema personalizadas.
Banco de prompts personal en tus notas o en las instrucciones de tu Proyecto.
Checklist de uso responsable.
Ficha de caso de uso de IA para tu área completada en la actividad de esta sesión.
```

### Imagen / tabla disponible
Lista de logros del curso con iconos verdes de verificación. El título incluye una etiqueta amarilla "PENDIENTE".

### Observaciones
Contiene marca o texto de contenido pendiente. Revisar si la etiqueta PENDIENTE debe eliminarse o reemplazarse por contenido final.

---

## Slide 40: Algunos recursos interesantes

### Título
Algunos recursos interesantes

### Contenido de texto
```text
Algunos recursos interesantes
One Useful Thing (Ethan Mollick)
Newsletter en inglés sobre IA aplicada al trabajo. Accesible, práctico y orientado a público no técnico. Permite recibir novedades
sobre IA en el correo electrónico.
Awesome Cloude Prompts
Colección más completa y usada de prompts para Claude. Prompts optimizados específicamente para Claude (Opus, Sonnet,
Haiku).
1001 casos de uso reales de IA generativa (Google)
Una recopilación de ejemplos reales en múltiples industrias: educación, salud, finanzas y más. Muy útil para mostrar aplicaciones
concretas en el mundo empresarial.
```

### Imagen / tabla disponible
Lista de recursos en formato de enlaces, cada uno precedido por un icono de enlace. No hay imagen adicional ni tabla.

### Observaciones
Incluye referencia o enlace externo; validar vigencia antes de compartir.

---

## Slide 41: Encuesta de cierre de curso PENDIENTE

### Título
Encuesta de cierre de curso PENDIENTE

### Contenido de texto
```text
Instrucciones.
1. Accede a la encuesta  a través del codigo
QR
2. Completa el cuestionario de la forma más
sincera posible (esto nos dará información
sobre como abordar cada tema).
Encuesta de cierre de curso PENDIENTE
```

### Imagen / tabla disponible
Código QR grande a la izquierda para encuesta de cierre y lista de instrucciones a la derecha. El título incluye etiqueta amarilla "PENDIENTE".

### Observaciones
Contiene marca o texto de contenido pendiente. Revisar si la etiqueta PENDIENTE debe eliminarse o reemplazarse por contenido final.

---

## Slide 42: Fin del curso

### Título
Fin del curso

### Contenido de texto
```text
Fin del curso
Curso de IA generativa, modelos de
lenguaje para productividad y uso
seguro en la empresa
```

### Imagen / tabla disponible
Diapositiva final con fondo negro, logotipos de Key Professionals y AGRISAL, título del curso y texto central "Fin del curso".

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

## Slide 43: Contacto Key Institute

### Título
Contacto Key Institute

### Contenido de texto
```text
www.keyinstitute.com
keyinstitute.sv
keyinstitutesv
Key Institute
```

### Imagen / tabla disponible
Slide de contacto: a la izquierda aparecen iconos de web, Instagram, LinkedIn y Facebook con datos de contacto; a la derecha el logotipo Key x Professionals sobre fondo azul degradado.

### Observaciones
No se identifican pendientes explícitos en el texto extraído.

---

